import "../CSS/style01.css"
import {Link} from "react-router-dom"

const Rodape = () => {
	return(
		    <Link to={"/sobre-nos"}>Sobre Nós<Link/>
    )
}

export default Rodape;