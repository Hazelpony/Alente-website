const MenuSaude = () => {
  //JavaScript aqui se precisar
  return(
    html aqui
  )
}

export default MenuSaude;