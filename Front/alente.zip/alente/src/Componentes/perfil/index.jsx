const Perfil = () => {
  //JavaScript aqui se precisar
  return(
    html aqui
  )
}

export default Perfil;