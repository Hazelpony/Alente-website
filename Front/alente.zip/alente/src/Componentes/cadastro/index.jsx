const Cadastro = () => {
  //JavaScript aqui se precisar
  return(
    html aqui
  )
}

export default Cadastro;