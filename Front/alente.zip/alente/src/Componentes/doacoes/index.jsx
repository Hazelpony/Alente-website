const Doacoes = () => {
  //JavaScript aqui se precisar
  return(
    html aqui
  )
}

export default Doacoes;