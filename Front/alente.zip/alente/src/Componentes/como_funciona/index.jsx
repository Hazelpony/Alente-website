const comoFunciona = () => {
  //JavaScript aqui se precisar
  return(
    html aqui
  )
}

export default comoFunciona;