const faleConosco = () => {
  //JavaScript aqui se precisar
  return(
    html aqui
  )
}

export default faleConosco;