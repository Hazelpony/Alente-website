const MenuOpcoes = () => {
  //JavaScript aqui se precisar
  return(
    html aqui
  )
}

export default MenuOpcoes;