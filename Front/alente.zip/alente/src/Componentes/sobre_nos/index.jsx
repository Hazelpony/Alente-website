const sobreNos = () => {
  //JavaScript aqui se precisar
  return(
    html aqui
  )
}

export default sobreNos;