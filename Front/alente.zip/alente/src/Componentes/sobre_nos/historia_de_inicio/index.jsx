const histInicio = () => {
  //JavaScript aqui se precisar
  return(
    html aqui
  )
}

export default histInicio;